-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: harmonized
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `role` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `uuid` char(38) NOT NULL,
  PRIMARY KEY (`role`),
  UNIQUE KEY `role_uuid_index` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES ('Accompagnateur','Accompagnateur','d89f8c86-0194-11f1-9bf2-00155d7396d9'),('Accompagnateur Leader','Accompagnateur Leader','d89f8f5f-0194-11f1-9bf2-00155d7396d9'),('Adults','Adults','d89f9115-0194-11f1-9bf2-00155d7396d9'),('Anonymous','Anonymous','d89f91b6-0194-11f1-9bf2-00155d7396d9'),('Authenticated','Authenticated','d89f91f5-0194-11f1-9bf2-00155d7396d9'),('Clinician','Clinician','d89f922b-0194-11f1-9bf2-00155d7396d9'),('Counselor','Counselor','d89f925e-0194-11f1-9bf2-00155d7396d9'),('Data Assistant','Data Assistant','d89f9292-0194-11f1-9bf2-00155d7396d9'),('Data Element Contributor','Data Element Contributor','d89f92cb-0194-11f1-9bf2-00155d7396d9'),('Data Manager','Data Manager','d89f92ff-0194-11f1-9bf2-00155d7396d9'),('Doctor','Doctor','d89f932f-0194-11f1-9bf2-00155d7396d9'),('General Registration Clerk','General Registration Clerk','d89f9364-0194-11f1-9bf2-00155d7396d9'),('Global Superuser','Global Superuser','d89f9675-0194-11f1-9bf2-00155d7396d9'),('Health Surveillance','Health Surveillance','d89f9395-0194-11f1-9bf2-00155d7396d9'),('HMIS lab order','HMIS lab order','d89f93c9-0194-11f1-9bf2-00155d7396d9'),('Hospital Attendant','Hospital Attendant','d89f9785-0194-11f1-9bf2-00155d7396d9'),('HSA','HSA','d89f93f9-0194-11f1-9bf2-00155d7396d9'),('Informatics Manager','Informatics Manager','d89f942c-0194-11f1-9bf2-00155d7396d9'),('Lab','Lab','d89f9462-0194-11f1-9bf2-00155d7396d9'),('Medical Assistant','Medical Assistant','d89f9493-0194-11f1-9bf2-00155d7396d9'),('Nurse','Nurse','d89f94c5-0194-11f1-9bf2-00155d7396d9'),('Paediatrics','Paediatrics','d89f94f9-0194-11f1-9bf2-00155d7396d9'),('Pharmacist','Pharmacist','d89f952a-0194-11f1-9bf2-00155d7396d9'),('Program Manager','Program Manager','d89f955a-0194-11f1-9bf2-00155d7396d9'),('Provider','Provider','d89f9587-0194-11f1-9bf2-00155d7396d9'),('Registration Clerk','Registration Clerk','d89f95b8-0194-11f1-9bf2-00155d7396d9'),('Social Worker','Social Worker','d89f95eb-0194-11f1-9bf2-00155d7396d9'),('SPINE clinician','SPINE clinician','d89f961a-0194-11f1-9bf2-00155d7396d9'),('Student Clinician','Student Clinician','d89f97c5-0194-11f1-9bf2-00155d7396d9'),('Superuser','Superuser','d89f9647-0194-11f1-9bf2-00155d7396d9'),('Supervisor','Supervisor','d89f96ad-0194-11f1-9bf2-00155d7396d9'),('System Developer','System Developer','d89f96e6-0194-11f1-9bf2-00155d7396d9'),('Therapeutic Feeding Clerk','Therapeutic Feeding Clerk','d89f971b-0194-11f1-9bf2-00155d7396d9'),('Vitals Clerk','Vitals Clerk','d89f9750-0194-11f1-9bf2-00155d7396d9');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-05 10:52:25
