DROP FUNCTION IF EXISTS patient_current_regimen;
DELIMITER //
CREATE FUNCTION `patient_current_regimen`(`my_patient_id` INT, `my_date` DATE) RETURNS varchar(10) CHARSET utf8mb3 COLLATE utf8mb3_unicode_ci
    DETERMINISTIC
BEGIN
  DECLARE max_obs_datetime DATETIME;
  DECLARE regimen VARCHAR(10) DEFAULT 'N/A';

  SET max_obs_datetime = (
    SELECT MAX(start_date)
    FROM orders
      INNER JOIN drug_order
        ON drug_order.order_id = orders.order_id
        AND drug_order.drug_inventory_id IN (SELECT * FROM arv_drug)
        AND orders.voided = 0
        AND DATE(orders.start_date) <= DATE(my_date)
    WHERE orders.patient_id = my_patient_id AND drug_order.quantity > 0
  );

  SET @drug_ids := (
    SELECT GROUP_CONCAT(DISTINCT(drug_order.drug_inventory_id) ORDER BY drug_order.drug_inventory_id ASC)
    FROM drug_order
      INNER JOIN arv_drug ON drug_order.drug_inventory_id = arv_drug.drug_id
      INNER JOIN orders ON drug_order.order_id = orders.order_id AND drug_order.quantity > 0
      INNER JOIN encounter
        ON encounter.encounter_id = orders.encounter_id
        AND encounter.voided = 0
        AND encounter.encounter_type = 22
    WHERE orders.voided = 0
      AND date(orders.start_date) = DATE(max_obs_datetime)
      AND encounter.patient_id = my_patient_id
    ORDER BY arv_drug.drug_id ASC
  );

  SET regimen = (
    SELECT DISTINCT name FROM (
      SELECT GROUP_CONCAT(drug.drug_id ORDER BY drug.drug_id ASC) AS drugs,
             regimen_name.name AS name
      FROM moh_regimen_combination AS combo
        INNER JOIN moh_regimen_combination_drug AS drug USING (regimen_combination_id)
        INNER JOIN moh_regimen_name AS regimen_name USING (regimen_name_id)
      GROUP BY combo.regimen_combination_id
    ) AS regimens
    WHERE drugs = @drug_ids
    LIMIT 1
  );

  IF regimen IS NULL THEN
    SET regimen = 'N/A';
  END IF;

  RETURN regimen;
END //
DELIMITER ;