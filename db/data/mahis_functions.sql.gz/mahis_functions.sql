CREATE OR REPLACE VIEW clinic_registration_encounter AS
SELECT
    e.encounter_id,
    e.encounter_type,
    e.patient_id,
    e.provider_id,
    e.location_id,
    e.form_id,
    e.encounter_datetime,
    e.creator,
    e.date_created,
    e.voided,
    e.voided_by,
    e.date_voided,
    e.void_reason,
    e.uuid,
    e.changed_by,
    e.date_changed
FROM encounter e
WHERE e.encounter_type = (
    SELECT encounter_type_id
    FROM encounter_type
    WHERE name = 'HIV CLINIC REGISTRATION'
    LIMIT 1
)
AND e.voided = 0;

CREATE OR REPLACE VIEW ever_registered_obs AS
SELECT
    `obs`.`obs_id` AS `obs_id`,
    `obs`.`person_id` AS `person_id`,
    `obs`.`concept_id` AS `concept_id`,
    `obs`.`encounter_id` AS `encounter_id`,
    `obs`.`order_id` AS `order_id`,
    `obs`.`obs_datetime` AS `obs_datetime`,
    `obs`.`location_id` AS `location_id`,
    `obs`.`obs_group_id` AS `obs_group_id`,
    `obs`.`accession_number` AS `accession_number`,
    `obs`.`value_group_id` AS `value_group_id`,
    `obs`.`value_boolean` AS `value_boolean`,
    `obs`.`value_coded` AS `value_coded`,
    `obs`.`value_coded_name_id` AS `value_coded_name_id`,
    `obs`.`value_drug` AS `value_drug`,
    `obs`.`value_datetime` AS `value_datetime`,
    `obs`.`value_numeric` AS `value_numeric`,
    `obs`.`value_modifier` AS `value_modifier`,
    `obs`.`value_text` AS `value_text`,
    `obs`.`date_started` AS `date_started`,
    `obs`.`date_stopped` AS `date_stopped`,
    `obs`.`comments` AS `comments`,
    `obs`.`creator` AS `creator`,
    `obs`.`date_created` AS `date_created`,
    `obs`.`voided` AS `voided`,
    `obs`.`voided_by` AS `voided_by`,
    `obs`.`date_voided` AS `date_voided`,
    `obs`.`void_reason` AS `void_reason`,
    `obs`.`value_complex` AS `value_complex`,
    `obs`.`uuid` AS `uuid`
FROM
    `obs`
WHERE
    `obs`.`concept_id` = (
        SELECT concept_id
        FROM concept_name
        WHERE name = 'Ever registered at ART clinic'
        LIMIT 1
    )
    AND `obs`.`voided` = 0
    AND `obs`.`value_coded` = (
        SELECT concept_id
        FROM concept_name
        WHERE name = 'Yes'
        LIMIT 1
    );